package com.pst.sms.util;

import java.sql.Connection;
import java.sql.DriverManager;

public class DbConnection {
private static Connection con = null;
 public static Connection getConn() {
	 
	 try {
		 Class.forName("com.mysql.jdbc.Driver");
		 con =  DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","dinga");
	 }catch(Exception e) {
		 e.printStackTrace();
	 }
	 
	 return con;
 }
	
}
